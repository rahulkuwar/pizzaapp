package com.example.pizzaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener {

    private CheckBox tomato,mushrooms,jalapeno,peppers,olives,pepperoni,onions,cheese;
    private Button calculate;
    private RadioGroup rg;
    private RadioButton rb1,rb2,rb3;
    private TextView qty;
    private double result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rg = findViewById(R.id.rg);
        rb1 = findViewById(R.id.rb1);
        rb2 = findViewById(R.id.rb2);
        rb3 = findViewById(R.id.rb3);
        tomato = findViewById(R.id.tomato);
        mushrooms = findViewById(R.id.mushrooms);
        jalapeno = findViewById(R.id.jalapeno);
        peppers = findViewById(R.id.peppers);
        olives = findViewById(R.id.olives);
        pepperoni = findViewById(R.id.pepperoni);
        onions = findViewById(R.id.onions);
        cheese = findViewById(R.id.cheese);
        qty = findViewById(R.id.qty);
        Button button=findViewById(R.id.calculate);
        rg.setOnCheckedChangeListener(this);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                double quantity = Double.parseDouble(qty.getText().toString());
                result = quantity * result;
                if(tomato.isChecked())
                    result = result + 2;
                if(mushrooms.isChecked())
                    result = result + 2;
                if(jalapeno.isChecked())
                    result = result + 2;
                if(peppers.isChecked())
                    result = result + 2;
                if(olives.isChecked())
                    result = result + 2;
                if(pepperoni.isChecked())
                    result = result + 2;
                if(onions.isChecked())
                    result = result + 2;
                if(cheese.isChecked())
                    result = result + 2;

                Toast.makeText(MainActivity.this,  "Final price : " + result + " Dollars", Toast.LENGTH_LONG).show();
                result = 0;
            }
        });

    }

    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
        switch(checkedId) {
            case R.id.rb1:
                result = 14.99;
                break;
            case R.id.rb2:
                result = 11.99;
                break;
            case R.id.rb3:
                result = 8.99;
                break;
        }

    }
}
